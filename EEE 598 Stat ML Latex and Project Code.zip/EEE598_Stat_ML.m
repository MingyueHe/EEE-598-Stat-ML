clear
load('Customer_DPR_NoMissingData_with_3D');
load('Day_type_2013.mat');
load('weather_2013.mat');

find_5=find(Customer_DPR_NoMissingData_with_3D(:,4,1)==5);
find_6=find(Customer_DPR_NoMissingData_with_3D(:,4,1)==6);
find_7=find(Customer_DPR_NoMissingData_with_3D(:,4,1)==7);
find_8=find(Customer_DPR_NoMissingData_with_3D(:,4,1)==8);
find_678=cat(1,find_6,find_7);
find_678=cat(1,find_678,find_8);
consumption_1=Customer_DPR_NoMissingData_with_3D(find_678,6:53,1);
consumption_rest_1=Customer_DPR_NoMissingData_with_3D(find_678,6:53,2:end);
consumption_rest_2=Customer_DPR_NoMissingData_with_3D(find_678,6:53,2:end);
consumption_rest_3=Customer_DPR_NoMissingData_with_3D(find_678,6:53,2:end);
consumption_rest_5month=Customer_DPR_NoMissingData_with_3D(find_5,6:53,2:end);
weather_2013=weather_2013(find_678,:);
weather_2013=weather_2013';
weather_2013=weather_2013(:);
clear find_5 find_6 find_7 find_8

for i=1:92
    a_find=find(consumption_1(i,:)==-1111);
    if isempty(a_find)
        continue
    end
    consumption_1(i,a_find(1):(a_find(end)+5))=-11;
    consumption_rest_1(i,(a_find(1)-1):(a_find(end)+4),:)=-11;
    consumption_rest_2(i,(a_find(1)-2):(a_find(end)+3),:)=-11;
    consumption_rest_3(i,(a_find(1)-3):(a_find(end)+2),:)=-11;
end

consumption_1=consumption_1';
consumption_1=consumption_1(:);
Kmean_Train_Consumption=consumption_1;
Kmean_Train_Consumption(Kmean_Train_Consumption==-11)=[];
Kmean_Train_Consumption=Kmean_Train_Consumption';
k=2;
for i=1:420
    rest_delay_customers=consumption_rest_1(:,:,i);
    rest_delay_customers=rest_delay_customers';
    rest_delay_customers=rest_delay_customers(:);
    rest_delay_customers(rest_delay_customers==-11)=[];
    rest_delay_customers=rest_delay_customers';
    New_with5month_rest_delay=cat(2,consumption_rest_5month(end,end,i),rest_delay_customers);
    kmean_additional=New_with5month_rest_delay(1:end-1);
    Kmean_Train_Consumption(k,:)=kmean_additional;
    k=k+1;
end
% only delay half hour
idx = kmeans(Kmean_Train_Consumption,5);%group number
SameGroup_idx=find(idx==idx(1));%find the group include customer1
Kmean_sameGroup=Kmean_Train_Consumption(SameGroup_idx,:);%prepare for calculating correlation coefficient in the same group
R = corrcoef(Kmean_Train_Consumption');%correlation coefficient for all
R_t = corrcoef(Kmean_Train_Consumption);%correlation coefficient for the values along the time

correl_coeff_sameGgroup=corrcoef(Kmean_sameGroup');%calculate correlation coefficient for the group including customer1
max_CorrelCoeff=max(correl_coeff_sameGgroup(1,2:end));%find the max correlation coefficient w.r.t. customer1
index_maxCC=find(correl_coeff_sameGgroup(1,2:end)==max_CorrelCoeff);%find the location index of the max correlation coefficient w.r.t. customer1
CustomerNumber_Delay_SameGroup=SameGroup_idx(index_maxCC);%get delay customer's number

month=Customer_DPR_NoMissingData_with_3D(find_678,4,1);
month=repmat(month,[1,48]);
month=month';
month=month(:);

day=Customer_DPR_NoMissingData_with_3D(find_678,5,1);
day=repmat(day,[1,48]);
day=day';
day=day(:);

m=1;
for i=6:length(consumption_1)
    month_find=find(Day_type_2013(:,2)==month(i));
    day_find=find(Day_type_2013(:,3)==day(i));
    day_type_3previousDay=intersect(month_find,day_find);
    Sample=Day_type_2013(day_type_3previousDay,4);
    
    Sample(1,end+1:end+5)=weather_2013((i-5):(i-1));
    Sample(end+1:end+6)=consumption_1((i-5):i);
    Sample_zeroFind=find(Sample==-11);
    if isempty(Sample_zeroFind)
        TrainDataSet_1(m,:)=Sample;
        m=m+1;
    end
end
Train_1=TrainDataSet_1(1:(end-48*4-1),:);
% save('C:\Users\he162\Desktop\trial-cust_half_hour\python��������\Train_1.mat','Train_1')
Test_1=TrainDataSet_1((end-48*4):(end),:);
% save('C:\Users\he162\Desktop\trial-cust_half_hour\python��������\Test_1.mat','Test_1')

m=1;
for i=6:length(consumption_1)
    month_find=find(Day_type_2013(:,2)==month(i));
    day_find=find(Day_type_2013(:,3)==day(i));
    day_type_3previousDay=intersect(month_find,day_find);
    Sample=Day_type_2013(day_type_3previousDay,4);
    
    Sample(1,end+1:end+5)=weather_2013((i-5):(i-1));
    Sample(end+1:end+6)=consumption_1((i-5):i);
    Sample_zeroFind=find(Sample==-11);
    if isempty(Sample_zeroFind)
        if Sample(1,1)==1
            TrainDataSet_Initial(m,:)=Sample;
            m=m+1;
        end
    end
end
Train_Initial=TrainDataSet_Initial(1:(end-48*3-1),:);
% save('C:\Users\he162\Desktop\trial-cust_half_hour\python��������\Train_Initial.mat','Train_Initial')
Test_Initial=TrainDataSet_Initial((end-48*3):(end),:);
% save('C:\Users\he162\Desktop\trial-cust_half_hour\python��������\Test_Initial.mat','Test_Initial')

Delay_degree=1;
Delay_Customer=Customer_DPR_NoMissingData_with_3D(find_678,6:53,CustomerNumber_Delay_SameGroup);
Delay_Customer=Delay_Customer';
Delay_Customer=Delay_Customer(:);
m=1;
for i=6:length(consumption_1)
    month_find=find(Day_type_2013(:,2)==month(i));
    day_find=find(Day_type_2013(:,3)==day(i));
    day_type_3previousDay=intersect(month_find,day_find);
    Sample=Day_type_2013(day_type_3previousDay,4);
    
    Sample(1,end+1:end+5)=weather_2013((i-5):(i-1));
    Sample(end+1:end+6)=consumption_1((i-5):i);
    Sample(end+1)=Delay_Customer(i-1);
    Sample([end-1,end])=Sample([end,end-1]);
    Sample_zeroFind=find(Sample==-11);
    if isempty(Sample_zeroFind)
        if Sample(1,1)==1
            TrainDataSet_WithDelayCustomer(m,:)=Sample;
            m=m+1;
        end
    end
end
Train_WithDelayCustomer=TrainDataSet_WithDelayCustomer(1:(end-48*3-1),:);
% save('C:\Users\he162\Desktop\trial-cust_half_hour\python��������\Train_WithDelayCustomer.mat','Train_WithDelayCustomer')
Test_WithDelayCustomer=TrainDataSet_WithDelayCustomer((end-48*3):(end),:);
% save('C:\Users\he162\Desktop\trial-cust_half_hour\python��������\Test_WithDelayCustomer.mat','Test_WithDelayCustomer')



consumption=Customer_DPR_NoMissingData_with_3D(find_678,6:53,1);
consumption=consumption';
consumption=consumption(:);

ConsumptionChange=zeros(length(consumption)-1,1);
for i=1:length(consumption)-1
    ConsumptionChange(i+1)=consumption(i+1)-consumption(i);
end
% ConsumptionChange(length(consumption))=0;
ConsumptionChange=reshape(ConsumptionChange,48,92);
ConsumptionChange=ConsumptionChange';
ConsumptionChange_01=zeros(size(ConsumptionChange));

threshold=0.22;

for i=1:48
    howMany_positive(i)=length(find(ConsumptionChange(:,i)>threshold));
    howMany_negative(i)=length(find(ConsumptionChange(:,i)<-threshold));
    ConsumptionChange_01(find(ConsumptionChange(:,i)>threshold),i)=1;
    ConsumptionChange_01(find(ConsumptionChange(:,i)<-threshold),i)=-1;
end
HowMany(1,:)=howMany_positive;
HowMany(2,:)=howMany_negative;

indicator_changePoint=zeros(1,48);
a=howMany_positive-howMany_negative;
b=howMany_negative-howMany_positive;
indicator_changePoint(find(a>10))=1;
indicator_changePoint(find(b>10))=-1;

indicator_changePoint=repmat(indicator_changePoint,[92,1]);
indicator_changePoint=indicator_changePoint';
indicator_changePoint=indicator_changePoint(:);

m=1;
for i=6:length(consumption_1)
    month_find=find(Day_type_2013(:,2)==month(i));
    day_find=find(Day_type_2013(:,3)==day(i));
    day_type_3previousDay=intersect(month_find,day_find);
    Sample=Day_type_2013(day_type_3previousDay,4);
    
    Sample(1,end+1:end+5)=weather_2013((i-5):(i-1));
    Sample(end+1:end+6)=consumption_1((i-5):i);
    Sample(end+1)=indicator_changePoint(i);
    Sample([end-1,end])=Sample([end,end-1]);
    Sample_zeroFind=find(Sample==-11);
    if isempty(Sample_zeroFind)
        if Sample(1,1)==1
            TrainDataSet_WithDelayCustomer_ChangePoint(m,:)=Sample;
            m=m+1;
        end
    end
end
Train_WithDelayCustomer_ChangePoint=TrainDataSet_WithDelayCustomer_ChangePoint(1:(end-48*3-1),:);
% save('C:\Users\he162\Desktop\trial-cust_half_hour\python��������\Train_WithDelayCustomer_ChangePoint.mat','Train_WithDelayCustomer_ChangePoint')
Test_WithDelayCustomer_ChangePoint=TrainDataSet_WithDelayCustomer_ChangePoint((end-48*3):(end),:);
save('C:\Users\he162\Desktop\trial-cust_half_hour\python��������\Test_WithDelayCustomer_ChangePoint.mat','Test_WithDelayCustomer_ChangePoint')

RMSE=[0.12888,0.07451,0.0732,0.064895];



